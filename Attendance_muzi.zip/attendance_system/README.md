# CyberAttend — Face Recognition Attendance System

Ek complete Computer Vision based Attendance System jo webcam se chehra scan kar ke
automatically attendance mark karta hai — naam, waqt (time) aur department ke saath.
Dashboard black background + neon (cyberpunk) style mein hai.

## Features
- 🔐 Admin-only login (username: `muzammil`, password: `muzammil182921`)
- 🏢 12 pre-loaded departments (aap khud bhi add kar sakte hain)
- 🎥 Webcam se live face detection & recognition (OpenCV Haar Cascade + LBPH)
- ➕ New person registration — naam + department enter karo, phir camera 60 face samples
  khud capture karta hai aur model train karta hai
- ✅ Jab registered banda dobara camera ke samne aata hai, uska naam, department aur
  time automatically dikh kar attendance database mein save ho jata hai (din mein 1 baar)
- 📊 Aesthetic dark/neon dashboard — total employees, departments, aaj ki attendance,
  department-wise chart
- 🧾 Reports page — date & department se filter kar ke history dekh sakte hain

## Requirements
- Python 3.9+
- A working webcam

## Installation

```bash
cd attendance_system
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

> Note: `opencv-contrib-python` (not plain `opencv-python`) is required because it
> includes `cv2.face.LBPHFaceRecognizer_create()`, jo face recognition ke liye use hota hai.

## Running the project

```bash
python app.py
```

Browser mein kholain: **http://127.0.0.1:5000**

Login:
- Username: `muzammil`
- Password: `muzammil182921`

## How to use

1. **Register Person** menu mein jayen → naam likhen, department select karen → Continue.
2. Camera automatically khulega aur chehre ke 60 samples capture karega
   (seedha camera mein dekhen, thora sa head hilate rahen).
3. Capture complete hone ke baad **"Finish & Train Model"** button dabayen —
   yeh model ko train kar dega.
4. Ab **Live Attendance** menu mein jayen — jab wo banda dobara camera ke samne
   aayega, uska naam, department aur time box ke upar dikhega aur attendance
   automatically DB mein mark ho jayegi (din mein sirf 1 dafa).
5. **Dashboard** par overall stats aur department-wise chart dekh sakte hain.
6. **Reports** mein date/department se filter kar ke pura attendance history
   dekh sakte hain.
7. **Employees** page se kisi bhi employee ko delete bhi kar sakte hain.

## Project structure

```
attendance_system/
├── app.py                # Flask app - routes, video streaming, logic
├── database.py           # SQLite database functions
├── face_utils.py         # Face detection / training / recognition (OpenCV)
├── requirements.txt
├── attendance.db          # Auto-created on first run
├── dataset/                # Captured face images per employee (auto-created)
├── trainer/trainer.yml     # Trained LBPH model (auto-created)
├── static/css/style.css   # Cyberpunk dark theme
└── templates/             # HTML pages (login, dashboard, register, capture, etc.)
```

## Notes / Tips
- Achi lighting mein registration karen — accuracy better hogi.
- Agar recognition kamzor lage to `face_utils.py` mein `CONFIDENCE_THRESHOLD`
  value ko chota (strict) ya bara (loose) kar sakte hain.
- Ek waqt mein sirf ek camera feed active honi chahiye (Register ya Attendance
  page ko band karen dosri kholne se pehle) — dono ek hi webcam share karte hain.
- Production mein deploy karne se pehle `app.py` mein `secret_key` change kar den.
- Zyada accurate face recognition chahiye ho (bade dataset ke sath) to future
  mein `face_recognition` (dlib based) library bhi use ki ja sakti hai, lekin
  installation thori mushkil hoti hai — is liye yahan OpenCV LBPH use kiya gaya
  hai jo har machine par asani se chal jata hai.
